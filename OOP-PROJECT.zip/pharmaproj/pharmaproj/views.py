from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib import auth


def home(request):
    return render(request, "homepage.html")


def cartpage(request):
    return render(request, "cartpage.html")

def product(request):
    return render(request, "product.html")

def register(request):

     if request.method == 'POST':
        username = request. POST['username']
        email = request. POST['email']
        password = request. POST['password']

        User = auth.authenticate(username=username, password=password)

        if User is not None:
            auth.login(request, User)
            return redirect("/")
        else:
            return redirect ('register')
     else:
            return render (request, 'login.html')

def login(request):
     if request.method == 'POST':
        username = request. POST['username']
        password = request. POST['password']

        User = auth.authenticate(username=username, password=password)

        if User is not None:
            auth.login(request, User)
            return redirect("/")
        else:
            return redirect ('login')
     else:
            return render (request, 'login.html')

def forgotpassword(request):
    return render(request,"forgot password.html")

def checkout(request):
    return render(request,"checkout.html")
